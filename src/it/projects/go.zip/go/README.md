# devfile-stack-go

A starter project for go
